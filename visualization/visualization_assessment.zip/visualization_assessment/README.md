Data Analysis and Visualization Assessment

Task | File
----- | -----
Data Preperation | Data_prep.ipynb
Q1 & Data Analysis | Data_analysis.ipynb
Q2 similar groups | Kmeans_clustering.ipynb 
Q2 & Recommendation | User_recommendation.ipynb 
trend analysis | Trend_analysis.ipynb
Sentiment analysis | Sentiment_analysis.ipynb

